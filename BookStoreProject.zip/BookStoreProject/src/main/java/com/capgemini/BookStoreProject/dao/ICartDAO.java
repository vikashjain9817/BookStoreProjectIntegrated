package com.capgemini.BookStoreProject.dao;


import java.util.Map;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;



public interface ICartDAO {

	public void clearCart();
	
	public Map<Integer, Cart> removeABookFromCart(int cartId);
	
	public Map<Integer, Cart> addABookToCart(Book book);
	
	public Map<Integer, Cart> addQuantityOfABook(int cartId);
	
	public Map<Integer,Cart> decreaseQuantityOfABook(int cartId);
	
	public Cart searchBook(int cartId);

	public Map<Integer, Cart> showAll();
	
	public double cartTotalPrice();
}
