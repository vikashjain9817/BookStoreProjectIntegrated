package com.capgemini.BookStoreProject.beans;

public class Cart {

	private Book book;
	private double total;
	private int quantity;
	private int cartId;
	
	
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public double getTotal() {
		return this.book.getPrice()*this.quantity;
	}
	public Cart(Book book, double total, Integer quantity, int cartId) {
		super();
		this.book = book;
		this.total = total;
		this.quantity = quantity;
		this.cartId = cartId;
	}
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setTotal(double total) {
		this.total = total;
	}
	
	
}
