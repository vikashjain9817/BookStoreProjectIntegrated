package com.capgemini.BookStoreProject.exceptions;

public class BookIdDoesNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookIdDoesNotExistException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	

}
