package com.capgemini.BookStoreProject.exceptions;



public class CategoryDoesNotExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CategoryDoesNotExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
