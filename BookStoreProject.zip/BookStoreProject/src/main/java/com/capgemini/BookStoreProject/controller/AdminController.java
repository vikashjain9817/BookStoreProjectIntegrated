package com.capgemini.BookStoreProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Category;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.beans.Users;
import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CategoryIdAlreadyExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.exceptions.OrderDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ReviewDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;
import com.capgemini.BookStoreProject.service.IAdminService;

@RestController
public class AdminController {
	
	@Autowired
	IAdminService adminService;
	
	
	@RequestMapping(value="/showAllUsers",method=RequestMethod.GET)
	public List<Users> showAllUsers()
	{
		return adminService.listAllUsers();
	}
	
	@RequestMapping(value="/showAllCustomers",method=RequestMethod.GET) 
	public List<RegisterCustomer> showAllCustomers()
	{
		return adminService.listAllCutomers();
	}
	
	
	@RequestMapping(value="/createUser",method=RequestMethod.PUT)
	public Users createUser(@RequestBody Users user) throws UserAlreadyExistException
	{
		return adminService.createUser(user);
	}
	
	@RequestMapping(value="/createCustomer",method=RequestMethod.PUT)
	public RegisterCustomer createCustomer(@RequestBody RegisterCustomer customer) throws CustomerAlreadyExistException
	{
		return adminService.registerCustomer(customer);
	}
	
	@RequestMapping(value="/deleteUser/{id}",method=RequestMethod.DELETE)
	public String deleteUser(@PathVariable int id) throws UserDoesNotExistException
	{
		return adminService.deleteUser(id);
	}
	
	@RequestMapping(value="/editUser/{id}",method=RequestMethod.PUT)
	public Users createUser(@PathVariable int id,@RequestBody Users user) throws UserDoesNotExistException
	{
		return adminService.editUser(id, user);
	}

	
	
	
	
	
	
	
	@RequestMapping(value = "/getOrdersForAdmin", method = RequestMethod.GET)
	public List<Orders> getOrdersAdmin() {
			return adminService.getOrdersForAdmin();
	}
	
	@RequestMapping(value = "/orderDetail/{orderId}", method = RequestMethod.GET)
	public Orders getOrderDetails(@PathVariable int orderId) {
			return adminService.getOrderDeatilsByOrderId(orderId);
	}
	
	@RequestMapping(value = "/updateOrderByAdmin", method = RequestMethod.PUT)
	public String updateOrderByAdmin(@RequestBody Orders order) throws OrderDoesNotExistException {
			adminService.updateOrderByAdmin(order);
			return "order updated successfully";
	}
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/createCategory",method=RequestMethod.PUT)
	public Category createCategory(@RequestBody Category category) throws CategoryIdAlreadyExistsException
	{
		
		return adminService.createCategory(category);
	}
	
	@RequestMapping(value="/showcategory",method=RequestMethod.GET)
	public List<Category> showCategory()
	{
		return adminService.findAllCategory();
	}
	
	@RequestMapping(value="/deleteCategory/{categoryId}",method=RequestMethod.DELETE)
	public Category deleteCategory(@PathVariable int categoryId) throws CategoryDoesNotExistsException
	{
		return adminService.deletecategory(categoryId);
	}
	

	@RequestMapping(value="/editCategory",method=RequestMethod.PUT)
	public Category editCategory(@RequestBody Category category) throws CategoryDoesNotExistsException
	{
		return adminService.editCategory(category);
	}	
	
	
	
	@RequestMapping(value="/showAllBooks",method=RequestMethod.GET)
	public List<Book> showAllBooks() throws NoBooksFoundException
	{
		return adminService.showAllBooks();
	}
	
	@RequestMapping(value="/createBooks",method=RequestMethod.PUT)
	public Book createBook(@RequestBody Book book) throws BookAlreadyExistException { 
		return adminService.createBook(book);
		}
	
	

	@RequestMapping(value="/findBookById/{id}",method=RequestMethod.GET) 
	public Book findBook(@PathVariable int id) throws BookIdDoesNotExistException { 
		return adminService.findBook(id);
		}
	
	
	@RequestMapping(value="/updateBook",method=RequestMethod.PUT)  
	public Book updateBook(@RequestBody Book book) throws BookDoesNotExistException {
		return adminService.update( book);
		}
	
	@RequestMapping(value="/deleteBook/{id}",method=RequestMethod.DELETE)
	public List<Book> delete(@PathVariable int id) throws   BookIdDoesNotExistException {
		return adminService.delete(id);
		
		}
	
	@RequestMapping(value="/bookInfo/{bookId}",method=RequestMethod.GET)
	public Book bookInfo(@PathVariable int bookId) throws BookIdDoesNotExistException
	{
		return adminService.findBook(bookId);
		
	}
	
	
	
	
	
	@RequestMapping(value="/editCustomer",method=RequestMethod.PUT)
	public List<RegisterCustomer> updateCustomer(@RequestBody RegisterCustomer customer) throws CustomerDoesNotExistException
	{
		return adminService.editCustomer(customer);

    }
	
	
	@RequestMapping(value="/deleteCustomer/{customerId}",method=RequestMethod.GET)
	public List<RegisterCustomer> deleteCustomer(@PathVariable int customerId) throws CustomerDoesNotExistException
	{
		return adminService.deleteCustomer(customerId);
	
    }
	
	
	@RequestMapping(value = "/findAllReviews/{bookId}", method = RequestMethod.GET)
	public List<Review> findAllReviews(@PathVariable int bookId) {
			return adminService.findAllReviews(bookId);
	} 
	
	@RequestMapping(value = "/updateReview/{reviewId}", method = RequestMethod.PUT)
	public List<Review> updateReviews(@RequestBody Review reviews,@PathVariable int reviewId) throws ReviewDoesNotExistException {
			return adminService.updateReview(reviews, reviewId);
	} 
	
	@RequestMapping(value = "/deleteReview/{reviewId}", method = RequestMethod.DELETE)
	public List<Review> deleteReviews(@PathVariable int reviewId) {
			return adminService.deleteReview(reviewId);
	} 
	
}
