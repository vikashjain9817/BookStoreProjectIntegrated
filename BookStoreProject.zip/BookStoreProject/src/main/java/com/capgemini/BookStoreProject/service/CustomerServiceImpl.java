package com.capgemini.BookStoreProject.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Cart;
import com.capgemini.BookStoreProject.beans.Orders;
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.dao.IBookDAO;
import com.capgemini.BookStoreProject.dao.ICartDAO;
import com.capgemini.BookStoreProject.dao.CartDAOImpl;
import com.capgemini.BookStoreProject.dao.ICustomerDAO;
import com.capgemini.BookStoreProject.dao.ICategoryDAO;
import com.capgemini.BookStoreProject.dao.IOrdersDAO;
import com.capgemini.BookStoreProject.dao.IReviewDao;
import com.capgemini.BookStoreProject.dao.IUserDAO;
import com.capgemini.BookStoreProject.exceptions.BookCannotBeAddedMoreAsItIsOutOfStockException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBookInTheCartException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;

@org.springframework.stereotype.Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	IUserDAO userDAO;
	
	@Autowired
	ICustomerDAO customerDAO;
	
	@Autowired
	IBookDAO bookDAO;
	
	@Autowired
	IOrdersDAO ordersDAO;
	
	@Autowired
	ICategoryDAO categoryDAO;
	
	@Autowired
	IReviewDao reviewDAO;
	
	ICartDAO customerCartMgmt = new CartDAOImpl();
	
//	@Override
//	public Users createUser(Users user) throws UserAlreadyExistException {
//	String email=user.getEmail();
//	List<Users> userList=listAllUsers();
//	for(Users list: userList)
//		{
//			if(email.equals(list.getEmail())) {
//				throw new UserAlreadyExistException("This user already exist");
//		}
//	}
//	userDAO.save(user);
//	return user;
//	}		

//	@Override
//	public RegisterCustomer registerCustomer(RegisterCustomer customer) throws CustomerAlreadyExistException {
//		String phonenumber=customer.getPhonenumber();
//		List<RegisterCustomer> customerList=listAllCutomers();
//		for(RegisterCustomer list:customerList)
//		{
//			if(phonenumber.equals(list.getPhonenumber()))
//				throw new CustomerAlreadyExistException("This customer already exist");
//		}
//			customerDAO.save(customer);
//			return customer;
//	}

	@Override
	public String clearCart() {
		customerCartMgmt.clearCart();
		return "Cart cleared successfully";
	}

	@Override
	public Map<Integer,Cart> addABookToCart(Book book) {
		Cart cart = customerCartMgmt.searchBook(book.getBookId());
		if(cart==null)
		{
			customerCartMgmt.addABookToCart(book);
			return customerCartMgmt.showAll();
		}
		else
		{
			cart.setQuantity(cart.getQuantity()+1);
			return customerCartMgmt.showAll();
		}
	}

	@Override
	public Map<Integer, Cart> removeABookFromCart(int cartId) throws BookDoesNotExistException {
		Cart cart = customerCartMgmt.searchBook(cartId);
		if(cart!=null)
		{
			customerCartMgmt.removeABookFromCart(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookDoesNotExistException("This book does not exist in your cart");
		
	}

	@Override
	public Map<Integer, Cart> addQuantityOfBook(int cartId) throws BookCannotBeAddedMoreAsItIsOutOfStockException {
		Book bookSearch = bookDAO.findById(cartId).get();
		if((bookSearch.getQuantity()-1)>=0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()-1);
			customerCartMgmt.addQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
		}
		else
			throw new BookCannotBeAddedMoreAsItIsOutOfStockException("No more quantity of this Book can be added as it has become OUT OF STOCK");
	}

//	@Override
//	public String deleteUser(int userId) throws UserDoesNotExistException {
//		if(userDAO.existsById(userId))
//		{
//			userDAO.deleteById(userId);
//			return "User Deleted Successfully";
//		}
//		else
//			throw new UserDoesNotExistException("This User does not exist");
//	}
//
//	@Override
//	public Users editUser(int userId,Users updatedUser) throws UserDoesNotExistException {
//		if(userDAO.existsById(userId))
//		{
//			userDAO.deleteById(userId);
//			userDAO.save(updatedUser);
//			return updatedUser;
//		}
//		else
//			throw new UserDoesNotExistException("This user does not exist");
//	}

	@Override
	public Map<Integer,Cart> decreaseQuantityOfBook(int cartId) {
		Book bookSearch = bookDAO.findById(cartId).get();
		Cart cart = customerCartMgmt.searchBook(cartId);
		if((cart.getQuantity()-1)==0)
		{
			bookSearch.setQuantity(bookSearch.getQuantity()+1);
			customerCartMgmt.decreaseQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
		}
		else
			{customerCartMgmt.decreaseQuantityOfABook(cartId);
			return customerCartMgmt.showAll();
			}
	}

//	@Override
//	public List<Users> listAllUsers() {
//		
//		return userDAO.findAll();
//	}
//	
//	@Override
//	public List<RegisterCustomer> listAllCutomers() {
//		
//		return customerDAO.findAll();
//	}


	@Override
	public Map<Integer, Cart> showCart() throws NoBookInTheCartException {
		Map<Integer,Cart> bookCart = customerCartMgmt.showAll();
		if(bookCart.size()>0)
		{
		return customerCartMgmt.showAll();
		}
		else
			throw new NoBookInTheCartException("There is no book in the cart");
	}
	
	public double cartTotal() throws NoBookInTheCartException
	{
		if(customerCartMgmt.cartTotalPrice()==0)
			throw new NoBookInTheCartException("There is no book in the cart");
		else
			return customerCartMgmt.cartTotalPrice();
	}

//	@Override
//	public List<Orders> getOrdersForAdmin() {
//		
//		return ordersDAO.findAll();
//	}
//	
//	@Override
//	public Orders getOrderDeatilsByOrderId(int orderId) {
//		
//		return ordersDAO.findById(orderId).get();
//	}
	
	@Override
	public List<Orders> confirmOrder(Orders order) throws CustomerDoesNotExistException {
		ordersDAO.save(order);
		Book book = order.getBook();
		book.setBookSold(book.getBookSold()+order.getBookCopies());
		bookDAO.saveAndFlush(book);
		return findAllOrdersOfPerticularCustomer(order.getCustomer().getCustomerId());
		
	}
	
	
	@Override
	public List<Orders> findAllOrdersOfPerticularCustomer(int customerId) throws CustomerDoesNotExistException
	{
		if(customerDAO.existsById(customerId)) {
			List<Orders> totalOrders = ordersDAO.findAll();
			List<Orders> returingOrders = new ArrayList<Orders>();
			for(Orders o : totalOrders)
			{
				if(o.getCustomer().getCustomerId() == customerId)
					returingOrders.add(o);
			}
			return returingOrders;
		}
		throw new CustomerDoesNotExistException("customer does not exist");
	}

	
//	@Override
//	public void updateOrderByAdmin(Orders order) throws OrderDoesNotExistException
//	{
//		if(!ordersDAO.existsById(order.getId()))
//			throw new OrderDoesNotExistException("Order does not exist");
//		ordersDAO.saveAndFlush(order);
//	}

	
	@Override
	public boolean login(String phoneNumber, String pass) throws CustomerDoesNotExistException  {
	
		List<RegisterCustomer> customerList = customerDAO.findAll();
		for(RegisterCustomer list: customerList)
		{
			if(phoneNumber.equals(list.getPhonenumber()))
			{
				String password =customerDAO.findPassbyPhoneNumber(phoneNumber);
				if(password.equals(pass)) {
					return true;
				}
					
			}
		}
		throw new CustomerDoesNotExistException("UserId or password is incorrect");
	}

//	@Override
//	public Category createCategory(Category category) throws CategoryIdAlreadyExistsException {
//		List<Category> categories = categoryDAO.findAll();
//		for (Category checkcategory:categories)
//		{
//			if(checkcategory.getCategoryName().equals(category.getCategoryName()))
//			{
//				throw new CategoryIdAlreadyExistsException("This Category Already Exists");
//			}
//		}
//		return categoryDAO.saveAndFlush(category);
//	}
//	
//	@Override
//	public List<Category> findAllCategory() {
//		return categoryDAO.findAll();
//	}
//
//	@Override
//	public Category deletecategory(int categoryId) throws CategoryDoesNotExistsException {
//		List<Category> categories = categoryDAO.findAll();
//		for(Category checkcategory:categories)
//		{
//			if(checkcategory.getCategoryId() == categoryId)
//			{
//				categoryDAO.deleteById(categoryId);
//				return null;
//			}
//		}
//		throw new CategoryDoesNotExistsException("Category Id does not exists");
//		
//	}
//
//	@Override
//	public Category editCategory(Category category) throws CategoryDoesNotExistsException {
//		List<Category> categories = categoryDAO.findAll();
//		for(Category checkcategory:categories)
//		{
//			if(checkcategory.getCategoryId() == category.getCategoryId())
//			{
//				return categoryDAO.saveAndFlush(category);
//			}
//		}
//		throw new CategoryDoesNotExistsException("Category Id does not exists");
//		
//	}

	@Override
	public List<Book> categoryBooks(String category) throws CategoryDoesNotExistsException {
		List<Book> books = bookDAO.findAll();
		List<Book> catBooks = new LinkedList<>();
		for(Book book:books)
		{
			if( book.getCategory().getCategoryName().equals(category) )
			{
				catBooks.add(book);
			}
		}
		if(catBooks.isEmpty())
		{
			throw new CategoryDoesNotExistsException("Category does not exists");
		}
		return catBooks;
		
	}

//	@Override
//	public List<Book> showAllBooks() throws NoBooksFoundException {
//		List<Book> allBooks =  bookDAO.findAll();
//		if(allBooks.isEmpty())
//		{
//			throw new NoBooksFoundException("No books Found");
//		}
//		return allBooks;
//	}

	@Override
	public List<Book> recentBooks() throws NoBooksFoundException {
		List<Book> books = bookDAO.findAll();
		List<Book> recentBook = new LinkedList<>();
		List<LocalDate> dates = new LinkedList<>();
		for(Book book:books)
		{
			dates.add(book.getPublishDate());
		}
		Collections.sort(dates);
		Collections.reverse(dates);
		for(LocalDate date:dates)
		{
			for(Book book:books)
			{
				if(date.compareTo(book.getPublishDate()) == 0)
				{
					recentBook.add(book);
				}
				
			}
		}
		if(recentBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return recentBook;
	}

	@Override
	public List<Book> bestSellingBooks() throws NoBooksFoundException {
		List<Book> books = bookDAO.findAll();
		List<Book> bestSellingBook = new LinkedList<>();
		List<Integer> noOfCopies = new LinkedList<>();
		for(Book book:books)
		{
			noOfCopies.add(book.getBookSold());
		}
		Collections.sort(noOfCopies);
		Collections.reverse(noOfCopies);
		for(Integer copies:noOfCopies)
		{
			for(Book book:books)
			{
				if(copies == book.getBookSold())
				{
					bestSellingBook.add(book);
				}
			}
		}
		if(bestSellingBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return bestSellingBook;
	}
	@Override
	public List<Book> mostFavoredBooks() throws NoBooksFoundException {
		List<Book> books = bookDAO.findAll();
		List<Book> mostFavoredBook = new LinkedList<>();
		List<Double> ratings = new LinkedList<>();
		for(Book book:books)
		{
			ratings.add(book.getRating());
		}
		Collections.sort(ratings);
		Collections.reverse(ratings);
		for(Double rating:ratings)
		{
			for(Book book:books)
			{
				if(rating.compareTo(book.getRating()) == 0)
				{
					mostFavoredBook.add(book);
				}
			}
		}
		if(mostFavoredBook.isEmpty())
		{
			throw new NoBooksFoundException("No books Found");
		}
		return mostFavoredBook;
	}

//	@Override
//	public Book createBook(Book book) throws BookAlreadyExistException {
//
//		List<Book> allBook= bookDAO.findAll();
//		for(Book book1:allBook)
//		{
//			if(book1.getTitle().equals(book.getTitle()))
//			{
//				throw new BookAlreadyExistException("Book ID Already Exist");
//			}
//		}
//		
//		return bookDAO.saveAndFlush(book);
//	}
//
//	@Override
//	public Book findBook(int id) throws BookIdDoesNotExistException {
//
//		if (!bookDAO.existsById(id))
//			throw new BookIdDoesNotExistException("Book Id does not Exist");
//
//		return bookDAO.findById(id).get();
//	}
//
//	@Override
//	public Book update(Book book) throws BookDoesNotExistException {
//		
//		if(!bookDAO.existsById(book.getBookId()))
//			throw new BookDoesNotExistException("Book Does Not Exist");
//		else {
//			return bookDAO.saveAndFlush(book);
//		}
//	}
//	
//	@Override
//	public List<Book> delete(int id) throws  BookIdDoesNotExistException {
//		
//		if(bookDAO.existsById(id)) {
//			bookDAO.deleteById(id);
//			return bookDAO.findAll();
//		}
//		else
//			throw new BookIdDoesNotExistException("Book Id does not exist");
//	}

	@Override
	public List<Review> bookReview(int bookId) {
		 Book book1=bookDAO.findById(bookId).get();
		 List<Review> li = new ArrayList<>();
		
			 li = reviewDAO.findByBook(book1);
			 return li;
			 
	}

//	@Override
//	public List<RegisterCustomer> editCustomer(RegisterCustomer customer) throws CustomerDoesNotExistException {
//		if(customerDAO.existsById(customer.getCustomerId())) {
//			customerDAO.saveAndFlush(customer);
//			return customerDAO.findAll();
//		}
//		throw new CustomerDoesNotExistException("customer does not exist");
//	}
//
//	@Override
//	public List<RegisterCustomer> deleteCustomer(int customerId) throws CustomerDoesNotExistException{
//		
//		if(customerDAO.existsById(customerId))
//		{
//			customerDAO.deleteById(customerId);
//			return customerDAO.findAll();
//		}
//		
//		throw new CustomerDoesNotExistException("customer does not exist");
//	}

	@Override
	public RegisterCustomer viewProfile(int customerId) throws CustomerDoesNotExistException {
		if(customerDAO.existsById(customerId))
		{
			return customerDAO.findById(customerId).get();
		}
		throw new CustomerDoesNotExistException("customer does not exist");
	}

	@Override
	public RegisterCustomer editProfile(RegisterCustomer customer) throws CustomerDoesNotExistException {
		
		if(customerDAO.existsById(customer.getCustomerId()))
		{
			customerDAO.saveAndFlush(customer);
		}
		throw new CustomerDoesNotExistException("customer does not exist");
	}


//	@Override
//	public List<Review> findAllReviews(int bookId) {
//	return reviewDAO.findAll();
//		
//	}
//
	@Override
	public List<Review> saveReviews(Review review,int bookId) throws BookDoesNotExistException {
		if(bookDAO.existsById(bookId))
		{
			reviewDAO.save(review);
			return reviewDAO.findAll();
		}
		else 
			throw new BookDoesNotExistException("This book does not exist");
	}
//
//	@Override
//	public List<Review> updateReview(Review review,int reviewId) throws ReviewDoesNotExistException {
//		if(reviewDAO.existsById(reviewId))
//		{
//			reviewDAO.deleteById(reviewId);
//			reviewDAO.save(review);
//			return reviewDAO.findAll();
//		}
//		else
//			throw new ReviewDoesNotExistException("This review does not exist");
//		
//	}
//	
//	
//	@Override
//	public List<Review> deleteReview(int reviewId) {
//      reviewDAO.deleteById(reviewId);
//	return reviewDAO.findAll();
//	}
}
