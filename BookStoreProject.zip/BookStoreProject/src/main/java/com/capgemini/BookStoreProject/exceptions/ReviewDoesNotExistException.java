package com.capgemini.BookStoreProject.exceptions;

public class ReviewDoesNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ReviewDoesNotExistException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
