package com.capgemini.BookStoreProject.exceptions;


public class CategoryIdAlreadyExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CategoryIdAlreadyExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
